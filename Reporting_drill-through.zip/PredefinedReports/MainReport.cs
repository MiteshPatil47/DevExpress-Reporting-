using System;
using DevExpress.XtraReports.UI;

namespace ASPNETCoreHowToCreateDrillDownReports
{
    public partial class MainReport
    {
        public MainReport()
        {
            InitializeComponent();
        }
    }
}
