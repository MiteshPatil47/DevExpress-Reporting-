using System;
using DevExpress.XtraReports.UI;

namespace ASPNETCoreHowToCreateDrillDownReports
{
    public partial class Details
    {
        public Details()
        {
            InitializeComponent();
        }
    }
}
